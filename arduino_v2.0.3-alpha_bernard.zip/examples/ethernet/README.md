Plotly+Arduino <3
==

Log, graph, share. Plotly+Arduino connects Arduinos to plotly''s beautiful online graphing tool for real-time, interactive data logging and graphing.

Plotly
--
[Plotly](https://plot.ly/) is an online web-app that helps you make and share beautiful, interactive graphs. 

![Plotly-Arduino library graph]()


Plotly has exposed a [REST API](https://plot.ly/api) that allows users to view graphs of their data online, in their browser.

